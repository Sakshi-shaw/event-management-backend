<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\StudentsModel;
use App\Models\TeachersModel;

class RegistrationController extends ResourceController
{
    public function register()
{
    // Get data from POST request (Frontend)
    $data = $this->request->getJSON(true);
    $email = $data['email'];
    $password = $data['password'];
    $firstName = $data['firstName'];
    $registerNumber = $data['registerNumber'];
    $lastName = $data['lastName'];
    $dept_id = $data['dept_id'];
    $phone = $data['phone'];
    $gender = $data['gender'];
    $college_id = $data['college_id'];
    $hashedPassword = "";
    
    try {
        // Password validation
        if (!$this->isValidPassword($password)) {
            
            return $this->respond([
                'message' => 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character.'
            ], 400); // HTTP 400 Bad Request
           
        }
        else{
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        }

        // Model for Students
        $studentModel = new StudentsModel();

        // Check if the email already exists in the students table
        $studentExists = $studentModel->where('email', $email)->first();

        if ($studentExists) {
            return $this->respond([
                'message' => 'This email is already registered.'
            ], 409); // HTTP 409 Conflict
        }

        // Insert the student's details into the database
        $studentModel->insert([
            'firstName' => $firstName,
            'lastName' => $lastName,
            'student_id' => $registerNumber,
            'email' => $email,
            'password' => $hashedPassword,
            'dept_id' => $dept_id,
            'phone' => $phone,
            'gender' => $gender,
            'college_id' => $college_id
        ]);
        return $this->respondCreated(['success' => "true", 'message' => 'Student registered successfully.'],200);
        //return $this->respondCreated(['success' => "true", 'message' => 'Student registered successfully.']);
    } catch (\Exception $e) {
        return $this->respond([
            'message' => 'Registration failed.',
            'error' => $e->getMessage()
        ], 500); // HTTP 500 Internal Server Error
    }
}

/**
 * Validate password based on criteria:
 * - At least 8 characters long
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one number
 * - At least one special character
 */
private function isValidPassword($password)
{
    $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/';
    return preg_match($pattern, $password);
}



//login

public function login()
{
    $data = $this->request->getJSON(true);
    $email = $data['email'];
    $password = $data['password'];  // Remove any leading or trailing spaces

    $studentModel = new StudentsModel();
    $teacherModel = new TeachersModel();

    $firstName = '';
    $lastName = '';
    $uicon='';

    try {
        // Check Teachers Table
        $teacher = $teacherModel->where('email', $email)->first();
        if ($teacher) {
            $firstName = $teacher['firstName']; // Fetch first name
            $lastName = $teacher['lastName']; 
            $uicon = strtoupper(substr($firstName, 0, 1)) . strtoupper(substr($lastName, 0, 1));
            //$verify = password_verify($password, $teacher['password']); 
            if ($data['password'] !== $teacher['password']) {
                return $this->respond(['status' => false, 'message' => 'Invalid username or password.'], 401);
            }
            else{
                return $this->respond([
                    'success'=>"true",
                    'message' => 'Login successful.',
                    'role' => 'teacher',
                    'id' => $teacher['id'],
                    'data' => [
                        'id' => $teacher['id'],
                        'firstName' => $teacher['firstName'],
                        'lastName' => $teacher['lastName'],
                        'email' => $teacher['email'],
                        'role_id' => $teacher['role_id'],
                        'dept_id' => $teacher['dept_id'],
                        'role' => 'teacher',
                        'uicon' => $uicon
                    ]
                ], 200);
            }
            // if ($teacher['password']===$password) {  // Compare plain text passwords
            //     return $this->respond([
            //         'success'=>"true",
            //         'message' => 'Login successful.',
            //         'role' => 'teacher',
            //         'data' => [
            //             'id' => $teacher['id'],
            //             'firstName' => $teacher['firstName'],
            //             'lastName' => $teacher['lastName'],
            //             'email' => $teacher['email'],
            //             'role_id' => $teacher['role_id'],
            //             'dept_id' => $teacher['dept_id'],
            //             'uicon' => $uicon
            //         ]
            //     ], 200);
            // } else {
            //     return $this->respond(['message' => 'Invalid credentials.'], 401);
            // }
        }

        // Check Students Table
        $student = $studentModel->where('email', $email)->first();
        
        if ($student) {
            $firstName = $student['firstName']; // Fetch first name
            $lastName = $student['lastName']; 
            $uicon = strtoupper(substr($firstName, 0, 1)) . strtoupper(substr($lastName, 0, 1));

            $verify = password_verify($password, $student['password']);
            if ($verify) {  // Compare plain text passwords
                return $this->respond([
                    'success'=>"true",
                    'message' => 'Login successful.',
                    'role' => 'student',
                    'id' => $student['id'],
                    'data' => [
                        'id' => $student['id'],
                        'firstName' => $student['firstName'],
                        'lastName' => $student['lastName'],
                        'email' => $student['email'],
                        'dept_id' => $student['dept_id'],
                        'uicon' => $uicon,
                        'role' => 'student'
                    ]
                ], 200);
            } else {
                return $this->respond(['message' => 'Invalid credentials.'], 401);
            }
        }

        return $this->respond(['message' => 'User not found.'], 404);
    } catch (\Exception $e) {
        return $this->respond([
            'message' => 'Login failed.',
            'error' => $e->getMessage()
        ], 500);
    }
}




}
